<?php

if(isset($_POST)){
    //  var_dump($_POST);
    //  var_dump($_FILES);

    $name = $_POST['name'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $profile = $_FILES['profile'];

    $base = 'photo/';
    $fullpath = $base.$profile['name'];

    // echo $fullpath;
    // die();
    move_uploaded_file($profile['tmp_name'], $fullpath); // filename , filepath

    $student = Array(
        'name' => $name,
        'email' => $email,
        'gender' => $gender,
        'address' => $address,
        'profile' => $fullpath
    );

    $jsonData = file_get_contents('studentlist.json');

    if(!$jsonData){
        $jsonData = '[]';
    }

    $arrayData = json_decode($jsonData, true);
    array_push($arrayData, $student);
    $jsonArray = json_encode($arrayData, JSON_PRETTY_PRINT);

    //echo file_put_contents('studentlist.json', $jsonArray) ? "success" : "failed!";
    file_put_contents('studentlist.json', $jsonArray);
    header("Location: index.php");

}