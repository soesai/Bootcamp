$(document).ready(function(){

    $(".oldNew").hide();

    $(".table").on('click','.delete',function(){
        var id = $(this).data('id');
        $.get('Delete.php', {id:id}, function( response ){
            console.log(response);
        });

        getStudent();
    });

    $(".table").on('click','.edit',function(){
        
        var id = $(this).data('id');
        $(".addform").hide();
        $(".table").hide();
        $(".oldNew").show();
        console.log("Profile ID => "+id);

        $.get('studentlist.json', function(response){
            console.log( typeof(response));
            var obj = new Array();
            if(typeof(response) != 'object'){
                obj = JSON.parse(response);
            }else{
                obj = response;
            }
            
            var name = obj[id].name;
            var email = obj[id].email;
            var address = obj[id].address;
            var gender = obj[id].gender;
            var profile = obj[id].profile;
            $(".ename").val(name);
            $(".eemail").val(email);
            $(".eaddress").val(address);

            console.log(gender);
            
            if(gender == 'Male'){
                $('.emale').prop('checked',true);
                $('.efemale').prop('checked',false);
            }else{
                $('.emale').prop('checked',false);
                $('.efemale').prop('checked',true);
            }

            $(".eaddress").val(address);
            
            $(".oldid").val(id);
            $('.oldpicture').attr('src',profile);
            $(".olddata").val(profile);
        }
    );
    });


    $(".table").on('click','.detail',function(){
        
        var id = $(this).data('id');
        console.log("Profile ID => "+id);

        $.get('studentlist.json', function(response){
            console.log( typeof(response));
            var obj = new Array();
            if(typeof(response) != 'object'){
                obj = JSON.parse(response);
            }else{
                obj = response;
            }
            
            var name = obj[id].name;
            var email = obj[id].email;
            var address = obj[id].address;
            var gender = obj[id].gender;
            var profile = obj[id].profile;
            $(".dname").text(name);
            $(".demail").text(email);
            $(".dgender").text(gender);
            $(".daddress").text(address);
            $('.dprofile').attr('src',profile);
        }
    );
    });


    getStudent();

    function getStudent(){
        $.get('studentlist.json', function(response){
            console.log( typeof(response));
            var obj = new Array();
            if(typeof(response) != 'object'){
                obj = JSON.parse(response);
            }else{
                obj = response;
            }
            var html = '';
            var no = 1;

            $.each(obj, function(i, v){
                var name = v.name;
                var email = v.email;
                var gender = v.gender;
                var address = v.address;
                var profile = v.profile;

                html += `<tr>
                <th scope="row">${no++}</th>
                <td>${name}</td>
                <td>${email}</td>
                <td>${gender}</td>
                <td>${address}</td>
                <td>
                    <button class="btn btn-primary detail" data-id="${i}" data-toggle="modal" data-target="#detail">Detail</button>
                    <button class="btn btn-success edit" data-id="${i}">Edit</button>
                    <button class="btn btn-danger delete" data-id="${i}">Delete</button>
                </td>
              </tr>`
            });

            $(".studentList").html(html);
        });
    }
});