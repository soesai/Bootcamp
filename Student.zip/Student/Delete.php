<?php

if(isset($_GET)){
    
    $id = $_GET['id'];
    $jsonData = file_get_contents('studentlist.json');
    $arrayData = json_decode($jsonData, true);
    unset($arrayData[$id]);

    $jsonArray = json_encode($arrayData, JSON_PRETTY_PRINT);
    file_put_contents('studentlist.json', $jsonArray);
    echo "Successfully Deleted!";
}