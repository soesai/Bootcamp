<?php

if(isset($_POST)){
    //  var_dump($_POST);
    //  var_dump($_FILES);

    $id = $_POST['oldid'];
    $name = $_POST['ename'];
    $email = $_POST['eemail'];
    $gender = $_POST['egender'];
    $address = $_POST['eaddress'];
    $profile = $_FILES['eprofile'];
    $olddata = $_POST['olddata'];

    if($profile['size'] > 0){
        $base = 'photo/';
        $fullpath = $base.$profile['name'];
        move_uploaded_file($profile['tmp_name'], $fullpath); // filename , filepath
        //unlink()
    }else{
        $fullpath = $olddata;
    }
    

   

    $student = Array(
        'name' => $name,
        'email' => $email,
        'gender' => $gender,
        'address' => $address,
        'profile' => $fullpath
    );

    //var_dump($student);
    $jsonData = file_get_contents('studentlist.json');


    $arrayData = json_decode($jsonData, true);
    $arrayData[$id] = $student;
    $jsonArray = json_encode($arrayData, JSON_PRETTY_PRINT);

    //echo file_put_contents('studentlist.json', $jsonArray) ? "success" : "failed!";
    file_put_contents('studentlist.json', $jsonArray);
    header("Location: index.php");

}