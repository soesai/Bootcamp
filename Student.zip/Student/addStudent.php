<form action="Add.php" method="POST" class="studentTable" enctype="multipart/form-data">

  <div class="form-row mt-5 mb-5">

    <div class="col-7">
        <h1 class="text-center">Add New Student</h1>
    </div>
      
    <div class="col-7">
        <Label>Profile</Label>
        <input type="file" class="form-control" name="profile" placeholder="File">
    </div>
    <div class="col-7">
        <Label>Name</Label>
        <input type="text" class="form-control" name="name" placeholder="Name">
    </div>
    <div class="col-7">
        <Label>Email</Label>
        <input type="email" class="form-control" name="email" placeholder="Email">
    </div>
    <div class="col-7">
    <div class="form-check">
        <input class="form-check-input" type="radio" name="gender"  value="Male" checked>
        <label class="form-check-label" for="gender">
            Male
        </label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="gender"  value="Female">
        <label class="form-check-label" for="gender">
            Female
        </label>
    </div>
    </div>

    <div class="col-7">
        <Label>Address</Label>
        <textarea name="address"  class="form-control" cols="20" rows="4"></textarea>
    </div>

    <div class="col-7 mt-4">
        <input type="submit" name="save" value="Save" class="btn btn-primary">
    </div>

  </div>
</form>
