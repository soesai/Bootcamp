<form action="Update.php" method="POST" class="studentTable" enctype="multipart/form-data">

  <div class="form-row mt-5 mb-5">
      
    <div class="col-7">
        <input type="text" name="oldid"  class="d-none oldid">
        <Label>Profile</Label>
        <input type="file" class="form-control" name="eprofile" placeholder="File">
        <input type="text" name="olddata" class="olddata d-none" id="">
    </div>
    <div class="col-7">
        <Label>Name</Label>
        <input type="text" class="form-control" name="ename" placeholder="Name">
    </div>
    <div class="col-7">
        <Label>Email</Label>
        <input type="email" class="form-control" name="eemail" placeholder="Email">
    </div>
    <div class="col-7">
    <div class="form-check">
        <input class="form-check-input emale" type="radio" name="egender" value="Male" checked>
        <label class="form-check-label" for="editgender">
            Male
        </label>
    </div>
    <div class="form-check">
        <input class="form-check-input efemale" type="radio" name="egender" value="Female">
        <label class="form-check-label" for="editgender">
            Female
        </label>
    </div>
    </div>

    <div class="col-7">
        <Label>Address</Label>
        <textarea name="eaddress"  class="form-control" cols="20" rows="4"></textarea>
    </div>

    <div class="col-7 mt-4">
        <input type="submit"  name="save" value="Update" class="btn btn-primary">
    </div>

  </div>
</form>
