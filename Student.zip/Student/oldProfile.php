<form action="Update.php" method="POST" class="" enctype="multipart/form-data">

  <div class="form-row mt-5 mb-5">
      
    <div class="col-7">
        <input type="text" name="oldid"  class="d-none oldid">
        <Label>Profile</Label><br>
        <!-- <input type="file" class="form-control eprofile" name="eprofile" placeholder="File"> -->
        <img src="" alt="" width="100px" height="100px" name="eimage" class="oldpicture">
    </div>
    <div class="col-7">
        <Label>Name</Label>
        <input type="text" class="form-control ename" name="ename" placeholder="Name">
    </div>
    <div class="col-7">
        <Label>Email</Label>
        <input type="email" class="form-control eemail" name="eemail" placeholder="Email">
    </div>
    <div class="col-7">
    <div class="form-check">
        <input class="form-check-input emale" type="radio" name="egender"  value="Male" checked>
        <label class="form-check-label" for="editgender">
            Male
        </label>
    </div>
    <div class="form-check">
        <input class="form-check-input efemale" type="radio" name="egender"  value="Female">
        <label class="form-check-label" for="editgender">
            Female
        </label>
    </div>
    </div>

    <div class="col-7">
        <Label>Address</Label>
        <textarea name="eaddress" class="form-control eaddress" cols="20" rows="4"></textarea>
    </div>

    <div class="col-7 mt-4">
        <!-- <input type="submit"  name="update" value="Update" class="btn btn-primary"> -->
    </div>

  </div>
</form>
